/*
 * This file is part of Cosmic IDE.
 * Cosmic IDE is a free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 * Cosmic IDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with Cosmic IDE. If not, see <https://www.gnu.org/licenses/>.
 */

// Top-level build file where you can add configuration options common to all subprojects/modules.
import java.util.Properties

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.kotlinx.serialization) apply false
    alias(libs.plugins.nmcp) apply false
    alias(libs.plugins.nmcpAggregation)
}

fun getLocalProperty(key: String): String? {
    val file = rootProject.file("local.properties")
    if (!file.exists()) return null
    val properties = Properties()
    file.inputStream().use { properties.load(it) }
    return properties.getProperty(key)?.trim('"')
}

nmcpAggregation {
    centralPortal {
        username.set(
            providers.environmentVariable("MAVEN_CENTRAL_USERNAME")
                .orElse(provider { getLocalProperty("MAVEN_CENTRAL_USERNAME") })
        )
        password.set(
            providers.environmentVariable("MAVEN_CENTRAL_PASSWORD")
                .orElse(provider { getLocalProperty("MAVEN_CENTRAL_PASSWORD") })
        )
    }
}

dependencies {
    nmcpAggregation(projects.pluginApi)
    nmcpAggregation(projects.ideApi)
}

tasks.register("publishSnapshots") {
    group = "publishing"
    description = "Publishes snapshot artifacts for API modules to Maven repository."
    dependsOn(":plugin-api:publishReleasePublicationToSonatypeSnapshotsRepository")
    dependsOn(":ide-api:publishReleasePublicationToSonatypeSnapshotsRepository")
}
