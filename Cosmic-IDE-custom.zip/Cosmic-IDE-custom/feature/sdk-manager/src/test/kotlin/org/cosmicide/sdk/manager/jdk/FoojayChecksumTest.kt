package org.cosmicide.sdk.manager.jdk

import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respondError
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files

class FoojayChecksumTest {
    // SHA-256("abc")
    private val abcSha256 = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"

    private fun verify(
        content: String,
        checksum: String,
        type: String = "sha256"
    ): Boolean = runBlocking {
        val httpClient = HttpClient(MockEngine { respondError(HttpStatusCode.NotFound) })
        val file = Files.createTempFile("cosmic-checksum", ".bin").toFile()
        try {
            file.writeText(content)
            FoojayClient(httpClient).verifyChecksum(
                file,
                FoojayClient.Artifact("v", "1", "https://x.test/a", checksum, "a", type)
            ).getOrThrow()
        } finally {
            httpClient.close()
            file.delete()
        }
    }

    @Test
    fun `matching sha256 is accepted case-insensitively`() {
        assertTrue(verify("abc", abcSha256))
        assertTrue(verify("abc", abcSha256.uppercase()))
        assertTrue(verify("abc", abcSha256, type = "SHA-256"))
    }

    @Test
    fun `mismatching or empty checksum is rejected`() {
        assertFalse(verify("abd", abcSha256))
        assertFalse(verify("abc", ""))
    }

    @Test
    fun `weak or unknown algorithms are rejected`() {
        assertFalse(verify("abc", "900150983cd24fb0d6963f7d28e17f72", type = "md5"))
        assertFalse(verify("abc", "a9993e364706816aba3e25717850c26c9cd0d89d", type = "sha1"))
        assertFalse(verify("abc", abcSha256, type = "crc32"))
    }
}
