# Custom build notes

Changes on top of upstream Cosmic IDE (main):

1. **Project JDK** - editor menu (⋮) -> "Project JDK" picks an installed JDK per project.
   Applies to new terminals, builds, and language servers (Kotlin/Gradle/custom LSP).
   Implementation: `Prefs.projectJdk/setProjectJdk/jdkNameFor`, `exec/ProjectJdk.kt`.
   Falls back to the global JDK (Settings -> Compiler) if none is chosen or it is uninstalled.
2. **Donation prompt disabled** (`DONATION_PROMPTS_ENABLED = false`).
3. **JDK downloads are verified** against the Foojay SHA-256/384/512 checksum before extraction
   (fails closed: missing checksum, weak algorithm or mismatch aborts the install).
4. **FilesDocumentsProvider hardened**: canonical-path confinement, name validation, root cannot be
   deleted/moved, no more world-readable/writable permission changes.
5. **glibc setup diagnostics**: the Environment Init screen now shows the real extraction error and
   free space, and removes a partial extraction so a retry starts clean.
6. **Robust glibc deployment**: a completion marker (`files/glibc/.cosmic-deployed`) is written only after a
   full extraction; a half-extracted runtime is no longer treated as ready, is wiped and re-extracted,
   and extraction can no longer be cancelled midway by leaving the screen.
7. **CI**: unit tests (`tests.yml`) now run on push/PR to main.

NOT changed (known issues): pacman `[gpkg]` repo in `app/src/main/assets/setup.sh` uses
`SigLevel = Never` over plain HTTP; release builds are signed with the committed debug key;
Git tokens are stored in global gitconfig.

NOTE: these edits were made without being able to compile (no Gradle/Maven access in the authoring
environment). If the first GitHub Actions run fails, send the error log.

## Build on GitHub
Push this folder's contents to a GitHub repo (public repos get free macOS minutes), open
Actions -> "Android CI" -> Run workflow. The APK appears under the run's Artifacts
(`app-arm64-v8a`). Optionally run "Tests CI" first.

## Branding / version
App label: "Ba1tossIDE" (`app_name` in `app/src/main/res/values*/strings.xml`).
Version: 0.0.1, versionCode 1 (`gradle/libs.versions.toml`: `ideVersion`, `ideVersionCode`).
applicationId stays `org.cosmicide` on purpose: runtime paths such as /data/data/org.cosmicide/files/arch
are baked into the glibc/setup scripts.

## Additions in 0.0.1 (second round)
8. **Project templates**: "New project from template" in the Create project sheet: Java (Gradle), Kotlin (Gradle), Fabric mod (JDK 21+). Scripts live in `app/src/main/assets/project-templates/`. Shown until you save your own list in Settings.
9. **Command quoting fix**: arguments passed to the shell are now single-quoted (`shellQuote`), fixing broken arguments with spaces/quotes.
10. **Build settings** (Settings → Compiler): Gradle JVM arguments and custom environment variables; applied to builds and the terminal.
11. **XML language server** (LemMinX) offered by default as a custom LSP.
12. **Android tools** (editor ⋮ menu → Android tools): launcher icon generator (mdpi–xxxhdpi) and strings.xml translator (MyMemory free API, placeholders protected).
Caveats: nothing was compiled by me; the first CI build may reveal compile errors. Machine translation needs internet and has a daily free quota.
13. The editor menu now shows the active JDK: "Project JDK (name)".
