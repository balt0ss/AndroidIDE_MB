# Custom build notes

Changes on top of upstream Cosmic IDE (main):

1. **Project JDK** - editor menu (⋮) -> "Project JDK" picks an installed JDK per project.
   Applies to new terminals, builds, and language servers (Kotlin/Gradle/custom LSP).
   Implementation: `Prefs.projectJdk/setProjectJdk/jdkNameFor`, `exec/ProjectJdk.kt`.
   Falls back to the global JDK (Settings -> Compiler) if none is chosen or it is uninstalled.
2. **Donation prompt disabled** (`DONATION_PROMPTS_ENABLED = false`).
3. **JDK downloads are verified** against the Foojay SHA-256/384/512 checksum before extraction
   (fails closed: missing checksum, weak algorithm or mismatch aborts the install).
4. **FilesDocumentsProvider hardened**: canonical-path confinement, name validation, root cannot be
   deleted/moved, no more world-readable/writable permission changes.
5. **CI**: unit tests (`tests.yml`) now run on push/PR to main.

NOT changed (known issues): pacman `[gpkg]` repo in `app/src/main/assets/setup.sh` uses
`SigLevel = Never` over plain HTTP; release builds are signed with the committed debug key;
Git tokens are stored in global gitconfig.

NOTE: these edits were made without being able to compile (no Gradle/Maven access in the authoring
environment). If the first GitHub Actions run fails, send the error log.

## Build on GitHub
Push this folder's contents to a GitHub repo (public repos get free macOS minutes), open
Actions -> "Android CI" -> Run workflow. The APK appears under the run's Artifacts
(`app-arm64-v8a`). Optionally run "Tests CI" first.
