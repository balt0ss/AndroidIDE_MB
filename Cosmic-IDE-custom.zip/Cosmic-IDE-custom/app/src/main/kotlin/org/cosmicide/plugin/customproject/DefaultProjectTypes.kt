package org.cosmicide.plugin.customproject

import android.content.Context

/**
 * Project types that are available out of the box (until the user saves their own list under
 * Settings > Extensions > Custom project types). The creation scripts live in
 * `assets/project-templates` so they stay readable and easy to edit.
 */
internal fun defaultProjectTypes(context: Context): List<CustomProjectTypeConfiguration> {
    fun script(name: String): String = runCatching {
        context.assets.open("project-templates/$name").bufferedReader().use { it.readText() }
    }.getOrDefault("")

    val gradleCommands = listOf(
        CustomProjectCommandConfiguration(
            id = "clean",
            name = "Clean",
            command = "./gradlew clean --console=plain"
        )
    )

    return listOf(
        CustomProjectTypeConfiguration(
            id = "builtin.java-gradle",
            name = "Java application (Gradle)",
            createCommand = script("java-gradle.sh"),
            buildCommand = "./gradlew build --console=plain",
            runCommand = "./gradlew run --console=plain",
            commands = gradleCommands
        ),
        CustomProjectTypeConfiguration(
            id = "builtin.kotlin-gradle",
            name = "Kotlin application (Gradle)",
            createCommand = script("kotlin-gradle.sh"),
            buildCommand = "./gradlew build --console=plain",
            runCommand = "./gradlew run --console=plain",
            commands = gradleCommands
        ),
        CustomProjectTypeConfiguration(
            id = "builtin.fabric-mod",
            name = "Fabric mod (template)",
            markerFiles = listOf("src/main/resources/fabric.mod.json"),
            createCommand = script("fabric-mod.sh"),
            buildCommand = "./gradlew build --console=plain",
            commands = listOf(
                CustomProjectCommandConfiguration(
                    id = "gen-sources",
                    name = "Generate sources",
                    command = "./gradlew genSources --console=plain"
                )
            ) + gradleCommands
        )
    )
}
