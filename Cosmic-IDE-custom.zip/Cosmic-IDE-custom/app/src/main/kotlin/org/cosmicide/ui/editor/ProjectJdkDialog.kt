package org.cosmicide.ui.editor

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.cosmicide.common.Prefs
import org.cosmicide.project.Project
import org.cosmicide.util.jdkNames

/**
 * Lets the user pick which installed JDK this project uses, or fall back to the global default
 * from Settings > Compiler. The choice applies to new terminals, builds and language servers.
 */
@Composable
internal fun ProjectJdkDialog(
    project: Project,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val installed = remember { context.jdkNames().sorted() }
    val globalName = remember { Prefs.currentJDK }
    var selected by remember(project.root.absolutePath) {
        mutableStateOf(Prefs.projectJdk(project.root))
    }
    val missingSelection = selected?.takeIf { it !in installed }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = {
            Text(
                "Project JDK",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "JDK used for this project's terminal, builds and language servers. " +
                            "Terminals and language servers that are already running keep their " +
                            "JDK until restarted or the project is reopened.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                JdkChoiceRow(
                    label = "Use global default ($globalName)",
                    selected = selected == null,
                    onClick = { selected = null }
                )
                installed.forEach { name ->
                    JdkChoiceRow(
                        label = name,
                        selected = selected == name,
                        onClick = { selected = name }
                    )
                }
                if (missingSelection != null) {
                    JdkChoiceRow(
                        label = "$missingSelection (not installed)",
                        selected = true,
                        onClick = {}
                    )
                }
                if (installed.isEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No JDKs are installed. Install one in Settings > Toolchains.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Prefs.setProjectJdk(project.root, selected)
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun JdkChoiceRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 12.dp)
        )
    }
}
