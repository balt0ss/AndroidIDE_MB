package org.cosmicide.editor.lsp

import android.content.Context

/**
 * Language servers offered out of the box. The XML server (Eclipse LemMinX) is downloaded on
 * first use by its starter script, so it needs a JDK and network access once.
 */
internal fun defaultLspConfigurations(context: Context): List<CustomLspConfiguration> {
    val script = runCatching {
        context.assets.open("lsp/lemminx.sh").bufferedReader().use { it.readText() }
    }.getOrDefault("")
    if (script.isBlank()) return emptyList()

    return listOf(
        CustomLspConfiguration(
            id = "builtin.xml-lemminx",
            name = "XML (LemMinX)",
            fileExtension = "xml",
            startScript = script,
            textMateGrammarLink =
                "https://raw.githubusercontent.com/microsoft/vscode/main/extensions/xml/syntaxes/xml.tmLanguage.json"
        ).normalized()
    )
}
