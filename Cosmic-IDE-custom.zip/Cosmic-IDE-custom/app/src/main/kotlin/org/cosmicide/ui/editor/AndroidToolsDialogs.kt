package org.cosmicide.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.cosmicide.project.Project

/** Generates ic_launcher.png / ic_launcher_round.png for every density from one picture. */
@Composable
internal fun IconGeneratorDialog(project: Project, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val resDir = remember(project.root.absolutePath) { AndroidTools.findResDir(project.root) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null || resDir == null) return@rememberLauncherForActivityResult
        busy = true
        status = "Generating…"
        scope.launch {
            status = try {
                val count = withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: error("Cannot read the picture")
                    val bitmap = AndroidTools.decode(bytes) ?: error("This is not a supported image")
                    AndroidTools.generateIcons(bitmap, resDir)
                }
                "Done: $count files written to ${resDir.relativeTo(project.root).path}/mipmap-*"
            } catch (e: Throwable) {
                "Failed: ${e.message}"
            }
            busy = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = {
            Text("Launcher icon", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = if (resDir == null) {
                        "No src/main/res folder found in this project."
                    } else {
                        "Pick a square-ish picture. It is cropped to a square and saved as " +
                                "ic_launcher and ic_launcher_round in mdpi–xxxhdpi."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    enabled = resDir != null && !busy,
                    onClick = { picker.launch(arrayOf("image/*")) }
                ) { Text("Choose picture") }
                if (status.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(status, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

/** Translates values/strings.xml into values-<lang>/strings.xml with a free online service. */
@Composable
internal fun StringsTranslatorDialog(project: Project, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val resDir = remember(project.root.absolutePath) { AndroidTools.findResDir(project.root) }
    var lang by remember { mutableStateOf("ru") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val source = resDir?.resolve("values/strings.xml")?.takeIf { it.isFile }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        shape = MaterialTheme.shapes.extraLarge,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        title = {
            Text("Translate strings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = if (source == null) {
                        "values/strings.xml was not found in this project."
                    } else {
                        "Translates values/strings.xml (from English) into the language below and " +
                                "writes values-<code>/strings.xml. Strings marked translatable=\"false\" " +
                                "are skipped. Machine translation: review the result."
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = lang,
                    onValueChange = { lang = it.trim().lowercase().take(5) },
                    label = { Text("Language code (ru, uk, de, fr…)") },
                    singleLine = true,
                    enabled = !busy
                )
                if (status.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(status, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = source != null && !busy && lang.matches(Regex("[a-z]{2,3}")),
                onClick = {
                    busy = true
                    scope.launch {
                        status = try {
                            withContext(Dispatchers.IO) {
                                val entries = AndroidTools.readStrings(source!!)
                                val out = ArrayList<AndroidTools.StringEntry>()
                                var kept = 0
                                for ((index, entry) in entries.withIndex()) {
                                    withContext(Dispatchers.Main) {
                                        status = "Translating ${index + 1}/${entries.size}…"
                                    }
                                    val (protectedText, placeholders) = AndroidTools.protect(entry.value)
                                    val translated = AndroidTools.translate(protectedText, "en", lang)
                                    val restored = AndroidTools.restore(translated, placeholders)
                                    if (restored == null) kept++
                                    out.add(AndroidTools.StringEntry(entry.name, restored ?: entry.value))
                                }
                                val target = resDir!!.resolve("values-$lang").also { it.mkdirs() }
                                    .resolve("strings.xml")
                                target.writeText(AndroidTools.renderStringsXml(out))
                                "Done: ${out.size} strings → values-$lang/strings.xml" +
                                        if (kept > 0) " ($kept kept in English: placeholders were lost)" else ""
                            }
                        } catch (e: Throwable) {
                            "Failed: ${e.message}"
                        }
                        busy = false
                    }
                }
            ) { Text("Translate") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Close") } }
    )
}
