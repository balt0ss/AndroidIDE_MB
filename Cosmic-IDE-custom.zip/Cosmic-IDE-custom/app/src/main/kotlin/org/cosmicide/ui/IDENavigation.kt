package org.cosmicide.ui

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.navigation3.rememberViewModelStoreNavEntryDecorator
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.runtime.rememberSaveableStateHolderNavEntryDecorator
import androidx.navigation3.ui.NavDisplay
import org.cosmicide.ui.editor.EditorScreen
import org.cosmicide.ui.home.HomeScreen
import org.cosmicide.ui.plugin.PluginScreenContent
import org.cosmicide.ui.resource.InstallResourcesScreen
import org.cosmicide.ui.resource.JdkSettingsPanel
import org.cosmicide.ui.settings.AboutSettingsScreen
import org.cosmicide.ui.settings.CompilerSettingsScreen
import org.cosmicide.ui.settings.EditorSettingsScreen
import org.cosmicide.ui.settings.ExtensionsSettingsScreen
import org.cosmicide.ui.settings.ExtensionsSettingsTab
import org.cosmicide.ui.settings.SettingsScreen
import org.cosmicide.ui.terminal.TerminalScreen
import org.cosmicide.util.ResourceUtil
import java.io.File

/**
 * Prepares a command to run in an interactive bash shell and then exit.
 * Uses double quotes to wrap the command, allowing bash features like process substitution to work.
 */
private fun commandWithExit(command: String): String {
    // Escape characters that need escaping in double quotes: backslash, double quote, dollar, backtick
    val escaped = command
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("$", "\\$")
        .replace("`", "\\`")
    return "bash -i -c \"$escaped && exit\""
}

@ExperimentalMaterial3Api
@Composable
fun IDENavigation() {
    val context = LocalContext.current
    val initialScreen: Screen = when {
        ResourceUtil.isBootstrapIncomplete() -> InstallResourceScreen
        ResourceUtil.isEnvironmentIncomplete() -> TerminalSetupScreen
        else -> Home
    }
    val backStack = rememberNavBackStack(
        initialScreen,
    )

    DisposableEffect(Unit) {
        onDispose {
        }
    }

    NavDisplay(
        backStack = backStack, onBack = { backStack.removeLastOrNull() }, entryDecorators = listOf(
            rememberSaveableStateHolderNavEntryDecorator(),
            rememberViewModelStoreNavEntryDecorator()
        )
    ) { key ->
        return@NavDisplay when (key) {
            is InstallResourceScreen -> NavEntry(key) {
                InstallResourcesScreen {
                    backStack.removeLastOrNull()
                    backStack.add(
                        TerminalSetupScreen
                    )
                }
            }

            is Home -> NavEntry(key) {
                HomeScreen(
                    onNavigateToEditor = { project ->
                        backStack.add(Editor(project))
                    },
                    onNavigateToSettings = { backStack.add(Settings) }
                )
            }

            is Editor -> NavEntry(key) {
                EditorScreen(key.project, onNavigateToPluginScreen = { pluginId, screenId, args ->
                    backStack.add(PluginScreen(pluginId, screenId, args))
                })
            }

            is Settings -> NavEntry(key) {
                SettingsScreen(
                    onBack = { backStack.removeLastOrNull() },
                    onNavigateToCategory = { category ->
                        backStack.add(SettingsCategoryScreen(category.destination))
                    },
                    onNavigateToPluginSettings = { id ->
                        backStack.add(PluginSettingsScreen(id))
                    }
                )
            }

            is SettingsCategoryScreen -> NavEntry(key) {
                when (key.destination) {
                    SettingsDestination.EDITOR ->
                        EditorSettingsScreen(onBack = { backStack.removeLastOrNull() })

                    SettingsDestination.COMPILER ->
                        CompilerSettingsScreen(onBack = { backStack.removeLastOrNull() })

                    SettingsDestination.EXTENSIONS ->
                        ExtensionsSettingsScreen(
                            onBack = { backStack.removeLastOrNull() },
                            onRunSetupInTerminal = { command ->
                                backStack.add(
                                    TerminalSession(
                                        command = commandWithExit(command),
                                        workingDirectory = context.filesDir.absolutePath
                                    )
                                )
                            },
                            onNavigateToPluginScreen = { pluginId, screenId, args ->
                                backStack.add(PluginScreen(pluginId, screenId, args))
                            },
                            initialTab = key.initialTab?.let { name ->
                                ExtensionsSettingsTab.entries.firstOrNull { it.name == name }
                            } ?: ExtensionsSettingsTab.PLUGINS
                        )

                    SettingsDestination.TERMINAL ->
                        TerminalScreen(onNavigateBack = { backStack.removeLastOrNull() })

                    SettingsDestination.TOOLCHAINS ->
                        JdkSettingsPanel { backStack.removeLastOrNull() }

                    SettingsDestination.ABOUT -> AboutSettingsScreen(gotoResourceScreen = {
                        backStack.add(
                            TerminalSetupScreen
                        )
                    }, onBack = { backStack.removeLastOrNull() })
                }
            }

            is JDKSettingsScreen -> NavEntry(key) {
                JdkSettingsPanel(onDismissRequested = {
                        backStack.removeLastOrNull()
                        backStack.add(
                            Home
                        )
                })
            }

            is TerminalSetupScreen -> NavEntry(key) {
                val setupScript = remember { ResourceUtil.prepareLanguageServerSetupScript() }
                TerminalScreen(
                    onNavigateBack = {
                        backStack.removeLastOrNull()
                        backStack.add(Home)
                    },
                    initialCommand = "bash ${setupScript.absolutePath} ${context.filesDir.absolutePath} ${context.cacheDir.absolutePath}",
                    workingDir = context.filesDir,
                    setup = true,
                    onProcessExit = { exitCode ->
                        if ((exitCode == 0) && !ResourceUtil.isEnvironmentIncomplete()) {
                            backStack.removeLastOrNull()
                            backStack.add(
                                SettingsCategoryScreen(
                                    destination = SettingsDestination.EXTENSIONS,
                                    initialTab = ExtensionsSettingsTab.PLUGINS.name
                                )
                            )
                        }
                    }
                )
            }

            is TerminalSession -> NavEntry(key) {
                TerminalScreen(
                    onNavigateBack = { backStack.removeLastOrNull() },
                    initialCommand = key.command,
                    workingDir = File(key.workingDirectory)
                )
            }

            is PluginSettingsScreen -> NavEntry(key) {
                val extension = remember(key.extensionId) {
                    org.cosmicide.plugin.CosmicPluginHost.enabledExtensions(UiExtensionPoints.SETTINGS_UI)
                        .find { it.id == key.extensionId }
                }
                if (extension != null) {
                    extension.Content()
                } else {
                    Text("Plugin settings not found")
                }
            }

            is PluginScreen -> NavEntry(key) {
                PluginScreenContent(
                    pluginId = key.pluginId,
                    screenId = key.screenId,
                    args = key.args,
                    onBack = { backStack.removeLastOrNull() }
                )
            }

            else -> NavEntry(key) {
                Text("Unknown screen: $key")
            }
        }
    }
}
