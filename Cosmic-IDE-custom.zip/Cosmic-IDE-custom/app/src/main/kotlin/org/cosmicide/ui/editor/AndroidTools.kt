package org.cosmicide.ui.editor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.File
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.xml.parsers.DocumentBuilderFactory

/** Helpers behind the "Android tools" menu: launcher icon generator and strings translator. */
internal object AndroidTools {

    val ICON_SIZES = linkedMapOf(
        "mipmap-mdpi" to 48,
        "mipmap-hdpi" to 72,
        "mipmap-xhdpi" to 96,
        "mipmap-xxhdpi" to 144,
        "mipmap-xxxhdpi" to 192
    )

    /** Finds `<module>/src/main/res`, preferring the conventional `app` module. */
    fun findResDir(projectRoot: File): File? {
        val candidates = listOf(
            projectRoot.resolve("app/src/main/res"),
            projectRoot.resolve("src/main/res")
        )
        candidates.firstOrNull(File::isDirectory)?.let { return it }
        return projectRoot.listFiles()
            ?.filter(File::isDirectory)
            ?.map { it.resolve("src/main/res") }
            ?.firstOrNull(File::isDirectory)
    }

    /** Writes ic_launcher.png and ic_launcher_round.png in every density. Returns files written. */
    fun generateIcons(source: Bitmap, resDir: File): Int {
        var written = 0
        for ((folder, size) in ICON_SIZES) {
            val dir = resDir.resolve(folder).also { it.mkdirs() }
            val scaled = squareCrop(source).let { Bitmap.createScaledBitmap(it, size, size, true) }
            for (name in listOf("ic_launcher.png", "ic_launcher_round.png")) {
                dir.resolve(name).outputStream().use {
                    scaled.compress(Bitmap.CompressFormat.PNG, 100, it)
                }
                written++
            }
        }
        return written
    }

    private fun squareCrop(bitmap: Bitmap): Bitmap {
        val side = minOf(bitmap.width, bitmap.height)
        return Bitmap.createBitmap(
            bitmap,
            (bitmap.width - side) / 2,
            (bitmap.height - side) / 2,
            side,
            side
        )
    }

    fun decode(bytes: ByteArray): Bitmap? =
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

    // ---- strings.xml translation -------------------------------------------------------------

    data class StringEntry(val name: String, val value: String)

    fun readStrings(file: File): List<StringEntry> {
        val factory = DocumentBuilderFactory.newInstance()
        val doc = factory.newDocumentBuilder().parse(file)
        val nodes = doc.getElementsByTagName("string")
        val result = ArrayList<StringEntry>()
        for (i in 0 until nodes.length) {
            val element = nodes.item(i) as Element
            if (element.getAttribute("translatable") == "false") continue
            val name = element.getAttribute("name")
            if (name.isEmpty()) continue
            result.add(StringEntry(name, element.textContent.orEmpty()))
        }
        return result
    }

    private val PLACEHOLDER = Regex("%(\\d+\\$)?[-#+ 0,(]*\\d*(\\.\\d+)?[a-zA-Z%]|\\\\n|\\{[^}]*}")

    /** Replaces format placeholders with numbered tokens so the translator leaves them alone. */
    fun protect(text: String): Pair<String, List<String>> {
        val found = ArrayList<String>()
        val out = PLACEHOLDER.replace(text) { match ->
            found.add(match.value)
            "[${found.size - 1}]"
        }
        return out to found
    }

    /** Puts placeholders back; returns null when the translator dropped one. */
    fun restore(translated: String, placeholders: List<String>): String? {
        var result = translated
        for ((index, value) in placeholders.withIndex()) {
            val token = "[$index]"
            if (!result.contains(token)) return null
            result = result.replace(token, value)
        }
        return result
    }

    fun escapeAndroid(text: String): String {
        val sb = StringBuilder()
        for (ch in text) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '\'' -> sb.append("\\'")
                '"' -> sb.append("\\\"")
                '@' -> sb.append("\\@")
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun renderStringsXml(entries: List<StringEntry>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n")
        for (entry in entries) {
            append("    <string name=\"").append(entry.name).append("\">")
            append(escapeAndroid(entry.value))
            append("</string>\n")
        }
        append("</resources>\n")
    }

    /** Translates through the free MyMemory API. Throws on network or quota errors. */
    fun translate(text: String, from: String, to: String): String {
        val url = URL(
            "https://api.mymemory.translated.net/get?q=" +
                    URLEncoder.encode(text, "UTF-8") +
                    "&langpair=" + URLEncoder.encode("$from|$to", "UTF-8")
        )
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            if (connection.responseCode != 200) {
                error("Translation service returned HTTP ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = com.google.gson.JsonParser.parseString(body).asJsonObject
            val status = json.get("responseStatus")?.asString
            if (status != null && status != "200") {
                error(json.get("responseDetails")?.asString ?: "Translation failed ($status)")
            }
            return json.getAsJsonObject("responseData").get("translatedText").asString
        } finally {
            connection.disconnect()
        }
    }
}
