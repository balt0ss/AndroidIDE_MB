# Eclipse LemMinX (XML language server). stdout carries LSP traffic, so all other output goes to stderr.
set -e
HOME_DIR="${HOME:-$APP_FILES_DIR/home}"
DIR="$HOME_DIR/.cosmic/lemminx"
JAR="$DIR/lemminx-uber.jar"

if [ ! -s "$JAR" ]; then
  mkdir -p "$DIR"
  BASE="https://repo1.maven.org/maven2/org/eclipse/lemminx/org.eclipse.lemminx"
  V="$(curl -fsSL "$BASE/maven-metadata.xml" | sed -n 's:.*<release>\(.*\)</release>.*:\1:p' | head -n1)"
  if [ -z "$V" ]; then
    echo "Could not determine the latest LemMinX version" >&2
    exit 1
  fi
  curl -fsSL -o "$JAR.tmp" "$BASE/$V/org.eclipse.lemminx-$V-uber.jar" >&2
  mv "$JAR.tmp" "$JAR"
fi

exec java -jar "$JAR"
