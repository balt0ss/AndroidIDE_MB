INIT_TYPE=kotlin-application
# Creates a Gradle project with `gradle init` (project type in INIT_TYPE).
# The Gradle distribution is downloaded once into ~/.cosmic and reused.
set -e
GV="${COSMIC_GRADLE_VERSION:-8.14.3}"
HOME_DIR="${HOME:-$APP_FILES_DIR/home}"
DIST="$HOME_DIR/.cosmic/gradle-$GV"

if [ ! -x "$DIST/bin/gradle" ]; then
  mkdir -p "$HOME_DIR/.cosmic"
  echo "Downloading Gradle $GV..."
  curl -fL --retry 3 -o "$HOME_DIR/.cosmic/gradle-$GV.zip" \
    "https://services.gradle.org/distributions/gradle-$GV-bin.zip"
  unzip -q -o "$HOME_DIR/.cosmic/gradle-$GV.zip" -d "$HOME_DIR/.cosmic"
  rm -f "$HOME_DIR/.cosmic/gradle-$GV.zip"
fi

# Use the major version of the active JDK so the generated toolchain matches it.
JV="$(java -version 2>&1 | sed -n 's/.*version "\([0-9][0-9]*\).*/\1/p' | head -n1)"
JV="${JV:-17}"
if [ "$JV" = "1" ]; then JV=8; fi

INIT_ARGS=(init --type "$INIT_TYPE" --dsl kotlin --package org.example \
  --project-name "$COSMIC_PROJECT_NAME" --use-defaults --no-daemon --console=plain)

"$DIST/bin/gradle" "${INIT_ARGS[@]}" --java-version "$JV" || "$DIST/bin/gradle" "${INIT_ARGS[@]}"
