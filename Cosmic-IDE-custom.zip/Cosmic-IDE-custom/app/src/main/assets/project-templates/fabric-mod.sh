# Fabric mod from the official example template. Requires git and a JDK matching the template.
set -e
git clone --depth 1 https://github.com/FabricMC/fabric-example-mod.git .
rm -rf .git
echo "Template ready. Edit gradle.properties (mod id, version) and run 'Generate sources'."
