/*
 * This file is part of Cosmic IDE.
 * Cosmic IDE is a free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
 * Cosmic IDE is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License along with Cosmic IDE. If not, see <https://www.gnu.org/licenses/>.
 */

package org.cosmicide.plugin.api

enum class PluginState {
    DISCOVERED,
    LOADED,
    ACTIVE,
    FAILED,
    DISABLED
}

data class PluginHandle(
    val descriptor: PluginDescriptor,
    val state: PluginState,
    val errorMessage: String? = null,
    val setupActions: List<PluginSetupAction> = emptyList()
)

sealed class PluginLoadResult {
    abstract val descriptor: PluginDescriptor

    data class Loaded(
        override val descriptor: PluginDescriptor,
        val plugin: CosmicPlugin
    ) : PluginLoadResult()

    data class Failed(
        override val descriptor: PluginDescriptor,
        val reason: String,
        val cause: Throwable? = null
    ) : PluginLoadResult()
}

interface PluginManager {
    val plugins: List<PluginHandle>

    fun load(descriptor: PluginDescriptor): PluginLoadResult

    fun unload(pluginId: String)
}
