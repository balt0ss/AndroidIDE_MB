package org.cosmicide.exec

import android.content.Context
import org.cosmicide.common.Prefs
import org.cosmicide.util.jdksDir
import java.io.File

/**
 * Resolves which installed JDK applies to a working directory.
 *
 * A per-project choice (see [Prefs.setProjectJdk]) wins when that JDK is still installed;
 * otherwise the global "active JDK" from settings is used, exactly as before.
 */
object ProjectJdk {

    fun resolve(context: Context, workingDir: File?): File {
        val jdks = context.applicationContext.jdksDir()
        val preferred = jdks.resolve(Prefs.jdkNameFor(workingDir))
        return if (preferred.isDirectory) preferred else jdks.resolve(Prefs.currentJDK)
    }
}
