package org.cosmicide.common

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class BuildEnvironmentTest {
    @Test
    fun `parses assignments comments quotes and export prefix`() {
        val env = BuildEnvironment.parse(
            """
            # comment
            FOO=bar
            export BAZ="two words"
            QUX='single'
            EMPTY=
            not a valid line
            1BAD=x
            """.trimIndent()
        )
        assertEquals("bar", env["FOO"])
        assertEquals("two words", env["BAZ"])
        assertEquals("single", env["QUX"])
        assertEquals("", env["EMPTY"])
        assertFalse(env.containsKey("1BAD"))
        assertEquals(4, env.size)
    }

    @Test
    fun `reserved runtime variables are ignored`() {
        val env = BuildEnvironment.parse("PATH=/x\nJAVA_HOME=/y\nHOME=/z\nLD_PRELOAD=a\nKEEP=1")
        assertEquals(mapOf("KEEP" to "1"), env)
    }

    @Test
    fun `gradle jvm args become GRADLE_OPTS and keep user options`() {
        assertEquals(
            mapOf("GRADLE_OPTS" to "-Dorg.gradle.jvmargs=\"-Xmx2g -Xms256m\""),
            BuildEnvironment.compose("", "-Xmx2g -Xms256m")
        )
        assertEquals(
            mapOf("GRADLE_OPTS" to "-Dfoo=1 -Dorg.gradle.jvmargs=\"-Xmx1g\""),
            BuildEnvironment.compose("GRADLE_OPTS=-Dfoo=1", "-Xmx1g")
        )
        assertEquals(emptyMap<String, String>(), BuildEnvironment.compose("", "  "))
    }

    @Test
    fun `quotes in jvm args are stripped`() {
        assertEquals(
            "-Dorg.gradle.jvmargs=\"-Xmx2g\"",
            BuildEnvironment.compose("", "\"-Xmx2g\"")["GRADLE_OPTS"]
        )
    }
}
