package org.cosmicide.common

/**
 * User-defined environment for terminals, builds and language servers.
 *
 * Two inputs are stored in preferences: free-form `KEY=VALUE` lines, and a convenience field for
 * the Gradle daemon JVM arguments (for example `-Xmx2g`), which is translated into `GRADLE_OPTS`.
 */
object BuildEnvironment {

    const val KEY_CUSTOM_ENV = "build_custom_env"
    const val KEY_GRADLE_JVM_ARGS = "build_gradle_jvm_args"

    /** Variables owned by the app's runtime; user values for these are ignored. */
    val RESERVED = setOf("PATH", "HOME", "JAVA_HOME", "LD_PRELOAD", "LD_LIBRARY_PATH")

    private val NAME = Regex("[A-Za-z_][A-Za-z0-9_]*")

    /** Parses `KEY=VALUE` lines; blank lines, `#` comments and an `export ` prefix are accepted. */
    fun parse(text: String): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        text.lineSequence().forEach { raw ->
            var line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach
            if (line.startsWith("export ")) line = line.removePrefix("export ").trim()

            val separator = line.indexOf('=')
            if (separator <= 0) return@forEach

            val name = line.substring(0, separator).trim()
            if (!NAME.matches(name) || name in RESERVED) return@forEach

            var value = line.substring(separator + 1).trim()
            if (value.length >= 2 &&
                ((value.startsWith("\"") && value.endsWith("\"")) ||
                        (value.startsWith("'") && value.endsWith("'")))
            ) {
                value = value.substring(1, value.length - 1)
            }
            result[name] = value
        }
        return result
    }

    /** Combines the free-form variables with the Gradle JVM arguments field. */
    fun compose(customEnvironment: String, gradleJvmArgs: String): Map<String, String> {
        val environment = LinkedHashMap(parse(customEnvironment))

        val args = gradleJvmArgs.replace("\"", "").replace("'", "").trim()
        if (args.isNotEmpty()) {
            val property = "-Dorg.gradle.jvmargs=\"$args\""
            val existing = environment["GRADLE_OPTS"]?.takeIf { it.isNotBlank() }
            environment["GRADLE_OPTS"] = listOfNotNull(existing, property).joinToString(" ")
        }
        return environment
    }

    /** The environment configured in settings; empty if preferences are unavailable. */
    fun fromPreferences(): Map<String, String> = runCatching {
        compose(Prefs.customEnvironmentText, Prefs.gradleJvmArgs)
    }.getOrDefault(emptyMap())
}
